clear; clc; close all;

fprintf('===================================================================\n');
fprintf('  TACTICAL STEALTH UAV - CONCEPTUAL DESIGN & FLIGHT DYNAMICS SUITE \n');
fprintf('===================================================================\n\n');

%% --- GLOBAL AIRCRAFT MISSION & GEOMETRY SPECIFICATIONS ---
ac.name        = 'Paninian-AeroX1 Tactical Stealth UAV';
ac.payload_kg  = 35.0;           % Mission payload (EO/IR + Avionics) [kg]
ac.crew_kg     = 0.0;            % Unmanned
ac.R_km        = 850.0;          % Mission Range [km]
ac.E_loiter_hr = 4.5;            % On-station loiter endurance [hr]
ac.V_cruise_ms = 75.0;           % Cruise speed [m/s] (~146 knots)
ac.alt_cr_m    = 5000.0;         % Cruise Altitude [m] (~16,400 ft)
ac.V_stall_ms  = 28.0;           % Maximum allowable stall speed [m/s]
ac.ROC_ms      = 12.0;           % Required sea-level rate of climb [m/s]
ac.S_to_m      = 220.0;          % Target Takeoff Ground Roll [m]
ac.n_max       = 6.0;            % Limit load factor [+g]
ac.n_min       = -3.0;           % Limit load factor [-g]

% Airframe Planform & Low-Observable (Stealth) Geometry
ac.AR          = 5.8;            % Wing Aspect Ratio (Cranked/Cropped Delta)
ac.sweep_deg   = 32.0;           % Leading-edge sweep angle [deg]
ac.taper_ratio = 0.35;           % Wing Taper Ratio
ac.t_c         = 0.11;           % NACA 64A-010 / Diamond airfoil thickness ratio
ac.e_oswald    = 0.82;           % Oswald efficiency factor
ac.CL_max_clean= 1.45;           % Max lift coefficient (clean)
ac.CL_max_to   = 1.70;           % Max lift coefficient (takeoff flap setting)
ac.CL_max_land = 1.95;           % Max lift coefficient (landing flap setting)

% Engine characteristics (Small Turbofan / High-Performance Prop-Turbine)
ac.SFC_cruise  = 0.65 / 3600;    % Specific Fuel Consumption [1/s]
ac.SFC_loiter  = 0.58 / 3600;    % Loiter SFC [1/s]

%% --- MODULE 1: MISSION SIZING & MASTER CONSTRAINT ANALYSIS ---
fprintf('[1/5] Executing Mission Sizing & Constraint Analysis...\n');
[ac, sizing_res] = run_module1_sizing(ac);

%% --- MODULE 2: AERODYNAMICS, POLAR BUILDUP & MOMENTS ---
fprintf('[2/5] Computing Aerodynamics, Low-Observable Drag Polar & Lift Curves...\n');
[ac, aero_res] = run_module2_aerodynamics(ac);

%% --- MODULE 3: FLIGHT PERFORMANCE & V-n MANEUVER ENVELOPE ---
fprintf('[3/5] Evaluating Flight Performance, Climb, Ceilings & V-n Envelope...\n');
[ac, perf_res] = run_module3_performance(ac, aero_res);

%% --- MODULE 4: 6-DOF STATIC & DYNAMIC STABILITY DERIVATIVES ---
fprintf('[4/5] Computing Stability Derivatives & State-Space Dynamic Modes...\n');
[ac, stab_res] = run_module4_stability(ac, aero_res);

%% --- MODULE 5: OPENVSP & DATCOM PARAMETRIC EXPORT ---
fprintf('[5/5] Generating Automated OpenVSP Parametric CAD Script & DATCOM Deck...\n');
run_module5_export(ac);

fprintf('\n===================================================================\n');
fprintf('  ALL 5 MODULES EXECUTED SUCCESSFULLY! CHECK FIGURES AND EXPORTS.  \n');
fprintf('===================================================================\n');


%% =========================================================================
%  LOCAL MODULE FUNCTIONS (EVERYTHING SELF-CONTAINED IN THIS FILE)
%% =========================================================================

%% --- MODULE 1 FUNCTION ---
function [ac, sizing_res] = run_module1_sizing(ac)
    g0 = 9.80665;
    rho_sl = 1.225;
    [~, ~, ~, rho_cr] = atmos_isa_local(ac.alt_cr_m);

    % Mission mass fractions
    MF_1 = 0.990; MF_2 = 0.992; MF_3 = 0.985; MF_4 = 0.980;
    LD_cruise = 14.5;
    MF_5 = exp(- (ac.R_km * 1000 * ac.SFC_cruise) / (ac.V_cruise_ms * LD_cruise));
    LD_loiter = 16.0;
    MF_6 = exp(- (ac.E_loiter_hr * 3600 * ac.SFC_loiter) / LD_loiter);
    MF_7 = 0.990; MF_8 = 0.995;

    MF_total = MF_1 * MF_2 * MF_3 * MF_4 * MF_5 * MF_6 * MF_7 * MF_8;
    M_fuel_frac = 1.06 * (1.0 - MF_total);

    % Statistical Empty Weight Regression
    a_reg = 0.96; c_reg = -0.07;
    W_fixed = ac.payload_kg + ac.crew_kg;
    W0_guess = 200.0; tol = 1e-4; err = 1.0;

    while err > tol
        We_frac = a_reg * (W0_guess^c_reg);
        W0_new = W_fixed / (1.0 - M_fuel_frac - We_frac);
        err = abs(W0_new - W0_guess);
        W0_guess = 0.5 * (W0_guess + W0_new);
    end

    ac.W0_kg    = W0_new;
    ac.We_kg    = We_frac * ac.W0_kg;
    ac.Wf_kg    = M_fuel_frac * ac.W0_kg;
    ac.W0_N     = ac.W0_kg * g0;

    fprintf('   -> Converged MTOW (W0)   : %6.2f kg (%7.1f N)\n', ac.W0_kg, ac.W0_N);
    fprintf('   -> Empty Weight (We)     : %6.2f kg (%.1f%%)\n', ac.We_kg, (ac.We_kg/ac.W0_kg)*100);
    fprintf('   -> Mission Fuel (Wf)     : %6.2f kg (%.1f%%)\n', ac.Wf_kg, (ac.Wf_kg/ac.W0_kg)*100);
    fprintf('   -> Payload Weight (Wp)   : %6.2f kg (%.1f%%)\n', ac.payload_kg, (ac.payload_kg/ac.W0_kg)*100);

    % Constraint Analysis
    WS_range = linspace(200, 1800, 300);
    CD0_est = 0.024;
    q_cr = 0.5 * rho_cr * ac.V_cruise_ms^2;

    WS_stall_max = 0.5 * rho_sl * (ac.V_stall_ms^2) * ac.CL_max_land;
    TW_takeoff = (1.21 .* WS_range) ./ (g0 * rho_sl * ac.CL_max_to * ac.S_to_m);
    TW_cruise = (q_cr * CD0_est) ./ WS_range + (WS_range) ./ (q_cr * pi * ac.AR * ac.e_oswald);

    V_roc = sqrt((2 .* WS_range) ./ (rho_sl * sqrt(CD0_est * pi * ac.AR * ac.e_oswald)));
    q_roc = 0.5 * rho_sl .* (V_roc.^2);
    TW_climb = (ac.ROC_ms ./ V_roc) + (q_roc * CD0_est) ./ WS_range + (WS_range) ./ (q_roc * pi * ac.AR * ac.e_oswald);

    n_turn = 3.5;
    [~, ~, ~, rho_turn] = atmos_isa_local(3000);
    q_turn = 0.5 * rho_turn * (65.0)^2;
    TW_turn = (q_turn * CD0_est) ./ WS_range + (WS_range ./ q_turn) * (n_turn^2 / (pi * ac.AR * ac.e_oswald));

    % Design Point
    ac.WS_design = 0.85 * WS_stall_max;
    TW_req_to    = interp1(WS_range, TW_takeoff, ac.WS_design);
    TW_req_cr    = interp1(WS_range, TW_cruise, ac.WS_design);
    TW_req_cl    = interp1(WS_range, TW_climb, ac.WS_design);
    TW_req_tn    = interp1(WS_range, TW_turn, ac.WS_design);
    ac.TW_design = 1.15 * max([TW_req_to, TW_req_cr, TW_req_cl, TW_req_tn]);

    ac.S_wing_m2  = ac.W0_N / ac.WS_design;
    ac.b_span_m   = sqrt(ac.AR * ac.S_wing_m2);
    ac.c_root_m   = (2 * ac.S_wing_m2) / (ac.b_span_m * (1 + ac.taper_ratio));
    ac.c_tip_m    = ac.c_root_m * ac.taper_ratio;
    ac.MAC_m      = (2/3) * ac.c_root_m * (1 + ac.taper_ratio + ac.taper_ratio^2) / (1 + ac.taper_ratio);
    ac.Thrust_sl_N= ac.TW_design * ac.W0_N;

    fprintf('   -> Selected Design Point : W/S = %5.1f N/m^2, T/W = %4.2f\n', ac.WS_design, ac.TW_design);
    fprintf('   -> Wing Reference Area   : %5.2f m^2\n', ac.S_wing_m2);
    fprintf('   -> Wingspan (b)          : %5.2f m\n', ac.b_span_m);
    fprintf('   -> Mean Aero Chord (MAC) : %5.2f m\n', ac.MAC_m);
    fprintf('   -> Installed SL Thrust   : %5.1f N (%4.1f kgf)\n', ac.Thrust_sl_N, ac.Thrust_sl_N/g0);

    % Plot Figure 1
    figure('Name', 'Figure 1 - Master Constraint Matching Diagram', 'Color', 'w', 'Position', [100 100 800 600]);
    plot(WS_range, TW_takeoff, 'r-', 'LineWidth', 2); hold on;
    plot(WS_range, TW_cruise, 'b-', 'LineWidth', 2);
    plot(WS_range, TW_climb, 'm-', 'LineWidth', 2);
    plot(WS_range, TW_turn, 'g-', 'LineWidth', 2);
    xline(WS_stall_max, 'k--', 'LineWidth', 2.5);
    plot(ac.WS_design, ac.TW_design, 'kp', 'MarkerFaceColor', 'y', 'MarkerSize', 14, 'LineWidth', 2);

    WS_feas = WS_range(WS_range <= WS_stall_max);
    TW_feas_bound = max([interp1(WS_range, TW_takeoff, WS_feas);
                         interp1(WS_range, TW_cruise, WS_feas);
                         interp1(WS_range, TW_climb, WS_feas);
                         interp1(WS_range, TW_turn, WS_feas)]);
    fill([WS_feas, fliplr(WS_feas)], [TW_feas_bound, 1.2*ones(size(TW_feas_bound))], ...
         [0.85 0.95 0.85], 'FaceAlpha', 0.4, 'EdgeColor', 'none');

    grid on; box on; xlim([200, 1600]); ylim([0, 1.0]);
    xlabel('Wing Loading, W/S (N/m^2)', 'FontSize', 12, 'FontWeight', 'bold');
    ylabel('Thrust-to-Weight Ratio, T/W (-)', 'FontSize', 12, 'FontWeight', 'bold');
    title(sprintf('%s - Master Constraint Sizing Matching Chart', ac.name), 'FontSize', 13, 'FontWeight', 'bold');
    legend({'Takeoff S_{TO} \le 220 m', 'Cruise V = 75 m/s', 'ROC \ge 12 m/s', ...
            'Sustained Turn 3.5g', 'Stall Limit V_{stall} \le 28 m/s', ...
            'Optimal Design Point', 'Feasible Solution Space'}, 'Location', 'northwest', 'FontSize', 10);

    sizing_res.WS_range = WS_range;
end

%% --- MODULE 2 FUNCTION ---
function [ac, aero_res] = run_module2_aerodynamics(ac)
    [~, ~, a_cr, rho_cr] = atmos_isa_local(ac.alt_cr_m);
    mu_cr = 1.63e-5;
    M_cr  = ac.V_cruise_ms / a_cr;
    beta_comp = sqrt(1 - M_cr^2);

    sweep_c2 = ac.sweep_deg - atand((2 * (ac.c_root_m - ac.c_tip_m) / ac.b_span_m) * 0.25);
    eta_airfoil = 0.95;

    CL_alpha_rad = (2 * pi * ac.AR) / ...
        (2 + sqrt(4 + ((ac.AR * beta_comp / eta_airfoil)^2) * (1 + (tand(sweep_c2)^2) / (beta_comp^2))));
    ac.CL_alpha_deg = CL_alpha_rad * (pi / 180);
    ac.CL_alpha_rad = CL_alpha_rad;
    ac.alpha_0L_deg = -1.2;

    % Parasite Drag Buildup
    Re_wing = (rho_cr * ac.V_cruise_ms * ac.MAC_m) / mu_cr;
    Cf_wing = 0.455 / ((log10(Re_wing))^2.58 * (1 + 0.144 * M_cr^2)^0.65);
    FF_wing = 1.0 + 1.2 * ac.t_c + 100 * (ac.t_c^4);
    CD0_wing = (Cf_wing * FF_wing * 1.00 * 2.05 * ac.S_wing_m2) / ac.S_wing_m2;

    L_fuse = 4.2; D_fuse = 0.68;
    Re_fuse = (rho_cr * ac.V_cruise_ms * L_fuse) / mu_cr;
    Cf_fuse = 0.455 / ((log10(Re_fuse))^2.58 * (1 + 0.144 * M_cr^2)^0.65);
    f_ld = L_fuse / D_fuse;
    FF_fuse = 1.0 + (60 / (f_ld^3)) + (f_ld / 400);
    CD0_fuse = (Cf_fuse * FF_fuse * 1.00 * 0.75 * pi * D_fuse * L_fuse) / ac.S_wing_m2;

    S_vtail = 0.22 * ac.S_wing_m2; c_vtail = 0.55;
    Re_tail = (rho_cr * ac.V_cruise_ms * c_vtail) / mu_cr;
    Cf_tail = 0.455 / ((log10(Re_tail))^2.58 * (1 + 0.144 * M_cr^2)^0.65);
    FF_tail = 1.0 + 1.2 * 0.10 + 100 * (0.10^4);
    CD0_vtail = (Cf_tail * FF_tail * 1.04 * 2.02 * S_vtail) / ac.S_wing_m2;

    CD0_misc = 0.05 * (CD0_wing + CD0_fuse + CD0_vtail);
    ac.CD0 = CD0_wing + CD0_fuse + CD0_vtail + CD0_misc;
    ac.K_ind = 1 / (pi * ac.AR * ac.e_oswald);
    ac.LD_max = 1 / (2 * sqrt(ac.CD0 * ac.K_ind));
    ac.CL_opt = sqrt(ac.CD0 / ac.K_ind);

    fprintf('   -> Lift Curve Slope (CL_alpha) : %5.3f /deg (%5.3f /rad)\n', ac.CL_alpha_deg, ac.CL_alpha_rad);
    fprintf('   -> Zero-Lift Drag (CD0)        : %6.4f (Wing: %.4f, Fuse: %.4f, Tail: %.4f)\n', ...
            ac.CD0, CD0_wing, CD0_fuse, CD0_vtail);
    fprintf('   -> Induced Drag Factor (K)     : %6.4f\n', ac.K_ind);
    fprintf('   -> Max Lift-to-Drag (L/D_max)  : %5.2f (at CL = %4.2f)\n', ac.LD_max, ac.CL_opt);

    alpha_deg = linspace(-4, 18, 200);
    CL = ac.CL_alpha_deg * (alpha_deg - ac.alpha_0L_deg);
    CL(CL > ac.CL_max_clean) = ac.CL_max_clean - 0.005 * (alpha_deg(CL > ac.CL_max_clean) - 14).^2;
    CD = ac.CD0 + ac.K_ind .* (CL.^2);
    LD_ratio = CL ./ CD;

    ac.Cm0 = 0.015; ac.Cm_alpha_deg = -0.018;
    Cm = ac.Cm0 + ac.Cm_alpha_deg .* alpha_deg;

    % Plot Figure 2
    figure('Name', 'Figure 2 - Aerodynamics & Low-Observable Drag Polar', 'Color', 'w', 'Position', [150 150 950 700]);
    subplot(2,2,1);
    plot(alpha_deg, CL, 'b-', 'LineWidth', 2); grid on; box on;
    xlabel('Angle of Attack, \alpha (deg)', 'FontWeight', 'bold');
    ylabel('Lift Coefficient, C_L (-)', 'FontWeight', 'bold');
    title('Lift Curve (C_L vs \alpha)');
    yline(ac.CL_max_clean, 'r--', 'LineWidth', 1.5, 'Label', 'C_{L,max}');

    subplot(2,2,2);
    plot(CD, CL, 'r-', 'LineWidth', 2); grid on; box on;
    xlabel('Drag Coefficient, C_D (-)', 'FontWeight', 'bold');
    ylabel('Lift Coefficient, C_L (-)', 'FontWeight', 'bold');
    title(sprintf('Drag Polar (C_D = %.4f + %.4f C_L^2)', ac.CD0, ac.K_ind));
    xline(ac.CD0, 'k:', 'C_{D0}');

    subplot(2,2,3);
    plot(alpha_deg, LD_ratio, 'k-', 'LineWidth', 2); grid on; box on;
    xlabel('Angle of Attack, \alpha (deg)', 'FontWeight', 'bold');
    ylabel('Aerodynamic Efficiency, L/D (-)', 'FontWeight', 'bold');
    title(sprintf('Efficiency Curve (Max L/D = %.2f)', ac.LD_max));
    yline(ac.LD_max, 'g--', 'LineWidth', 1.5);

    subplot(2,2,4);
    plot(alpha_deg, Cm, 'm-', 'LineWidth', 2); grid on; box on;
    xlabel('Angle of Attack, \alpha (deg)', 'FontWeight', 'bold');
    ylabel('Pitching Moment, C_m (c/4) (-)', 'FontWeight', 'bold');
    title('Pitching Moment Slope (\partial C_m / \partial \alpha < 0)');
    yline(0, 'k-'); xline(ac.alpha_0L_deg, 'k:');

    aero_res.alpha_deg = alpha_deg;
    aero_res.CL        = CL;
    aero_res.CD        = CD;
end

%% --- MODULE 3 FUNCTION ---
function [ac, perf_res] = run_module3_performance(ac, ~)
    g0 = 9.80665; rho_sl = 1.225;
    V_vec = linspace(15, 120, 250);
    altitudes = [0, 2500, 5000, 7500];
    T_req_mat = zeros(length(altitudes), length(V_vec));
    T_av_mat  = zeros(length(altitudes), length(V_vec));
    ROC_max_vec = zeros(size(altitudes));

    for i = 1:length(altitudes)
        [~, ~, ~, rho_h] = atmos_isa_local(altitudes(i));
        sigma_h = rho_h / rho_sl;
        q_vec = 0.5 * rho_h .* (V_vec.^2);
        CL_vec = ac.W0_N ./ (q_vec .* ac.S_wing_m2);
        CD_vec = ac.CD0 + ac.K_ind .* (CL_vec.^2);
        T_req = q_vec .* ac.S_wing_m2 .* CD_vec;
        T_req_mat(i, :) = T_req;
        T_av = ac.Thrust_sl_N * (sigma_h^0.85) * ones(size(V_vec));
        T_av_mat(i, :) = T_av;
        ROC_vec = ((T_av - T_req) .* V_vec) ./ ac.W0_N;
        ROC_max_vec(i) = max(ROC_vec);
    end

    [~, ~, ~, rho_0] = atmos_isa_local(0);
    q_sl_vec = 0.5 * rho_0 .* (V_vec.^2);
    CL_sl = ac.W0_N ./ (q_sl_vec .* ac.S_wing_m2);
    CD_sl = ac.CD0 + ac.K_ind .* (CL_sl.^2);
    T_req_sl = q_sl_vec .* ac.S_wing_m2 .* CD_sl;
    ROC_sl_curve = ((ac.Thrust_sl_N - T_req_sl) .* V_vec) ./ ac.W0_N;
    [ac.ROC_max_sl, idx_vy] = max(ROC_sl_curve);
    ac.V_y = V_vec(idx_vy);

    alt_dense = linspace(0, 14000, 100);
    ROC_dense = interp1(altitudes, ROC_max_vec, alt_dense, 'pchip', 'extrap');
    idx_service  = find(ROC_dense <= 0.5, 1, 'first');
    idx_absolute = find(ROC_dense <= 0.0, 1, 'first');
    if isempty(idx_service), ac.ServiceCeiling_m = 9200; else, ac.ServiceCeiling_m = alt_dense(idx_service); end
    if isempty(idx_absolute), ac.AbsoluteCeiling_m = 10400; else, ac.AbsoluteCeiling_m = alt_dense(idx_absolute); end

    % Range & Endurance
    [~, ~, ~, rho_cr] = atmos_isa_local(ac.alt_cr_m);
    q_cr = 0.5 * rho_cr * (ac.V_cruise_ms^2);
    CL_cr = ac.W0_N / (q_cr * ac.S_wing_m2);
    CD_cr = ac.CD0 + ac.K_ind * (CL_cr^2);
    LD_cr = CL_cr / CD_cr;

    W_initial = ac.W0_N;
    W_final   = (ac.W0_kg - ac.Wf_kg) * g0;
    ac.MaxRange_km = (ac.V_cruise_ms / (ac.SFC_cruise * g0)) * (LD_cr) * log(W_initial / W_final) / 1000;
    ac.MaxEndurance_hr = (1 / (ac.SFC_loiter * g0)) * (ac.LD_max) * log(W_initial / W_final) / 3600;

    V_to = 1.15 * ac.V_stall_ms;
    q_to = 0.5 * rho_sl * (0.707 * V_to)^2;
    L_to = q_to * ac.S_wing_m2 * ac.CL_max_to;
    D_to = q_to * ac.S_wing_m2 * (ac.CD0 + ac.K_ind * (ac.CL_max_to^2));
    mu_r = 0.03;
    F_accel = ac.Thrust_sl_N - D_to - mu_r * (ac.W0_N - L_to);
    ac.S_to_actual_m = (ac.W0_kg * (V_to^2)) / (2 * F_accel);

    V_land = 1.20 * ac.V_stall_ms;
    mu_brake = 0.35;
    ac.S_land_m = (ac.W0_kg * (V_land^2)) / (2 * mu_brake * ac.W0_N);

    fprintf('   -> Sea Level Max Climb Rate (ROC_max) : %5.2f m/s (at Vy = %4.1f m/s)\n', ac.ROC_max_sl, ac.V_y);
    fprintf('   -> Service Ceiling (ROC = 0.5 m/s)    : %5.0f m (%5.0f ft)\n', ac.ServiceCeiling_m, ac.ServiceCeiling_m*3.28084);
    fprintf('   -> Absolute Ceiling (ROC = 0 m/s)      : %5.0f m (%5.0f ft)\n', ac.AbsoluteCeiling_m, ac.AbsoluteCeiling_m*3.28084);
    fprintf('   -> Calculated Max Range (Breguet)      : %5.1f km\n', ac.MaxRange_km);
    fprintf('   -> Calculated Max Endurance            : %5.2f hours\n', ac.MaxEndurance_hr);
    fprintf('   -> Takeoff Ground Roll (S_to)          : %5.1f m (Requirement: %4.0f m)\n', ac.S_to_actual_m, ac.S_to_m);
    fprintf('   -> Landing Ground Roll (S_land)        : %5.1f m\n', ac.S_land_m);

    % V-n Diagram
    V_env = linspace(0, 140, 300);
    V_C   = ac.V_cruise_ms;
    V_D   = 1.25 * V_C;
    n_pos_stall = (0.5 * rho_sl .* (V_env.^2) * ac.S_wing_m2 * ac.CL_max_clean) ./ ac.W0_N;
    CL_min_clean = -0.90;
    n_neg_stall = (0.5 * rho_sl .* (V_env.^2) * ac.S_wing_m2 * CL_min_clean) ./ ac.W0_N;
    V_A = sqrt((2 * ac.n_max * ac.W0_N) / (rho_sl * ac.S_wing_m2 * ac.CL_max_clean));

    mu_g = (2 * ac.WS_design) / (rho_sl * g0 * ac.MAC_m * ac.CL_alpha_rad);
    Kg = (0.88 * mu_g) / (5.3 + mu_g);
    U_de_cruise = 15.24;
    n_gust_pos_cr = 1 + (Kg * rho_sl * ac.CL_alpha_rad * U_de_cruise .* V_env) ./ (2 * ac.WS_design);
    n_gust_neg_cr = 1 - (Kg * rho_sl * ac.CL_alpha_rad * U_de_cruise .* V_env) ./ (2 * ac.WS_design);

    % Plot Figure 3
    figure('Name', 'Figure 3 - Flight Performance & V-n Envelope', 'Color', 'w', 'Position', [200 200 1000 700]);
    subplot(2,2,1);
    plot(V_vec, T_req_mat(1,:), 'b-', 'LineWidth', 1.8); hold on;
    plot(V_vec, T_req_mat(3,:), 'b--', 'LineWidth', 1.8);
    plot(V_vec, T_av_mat(1,:), 'r-', 'LineWidth', 1.8);
    plot(V_vec, T_av_mat(3,:), 'r--', 'LineWidth', 1.8);
    grid on; box on; ylim([0, max(ac.Thrust_sl_N * 1.2, 1200)]);
    xlabel('True Airspeed, V (m/s)', 'FontWeight', 'bold');
    ylabel('Thrust, T (N)', 'FontWeight', 'bold');
    title('Thrust Required vs Available');
    legend({'T_{req} (Sea Level)', 'T_{req} (5000m)', 'T_{avail} (Sea Level)', 'T_{avail} (5000m)'}, ...
           'Location', 'northwest', 'FontSize', 9);

    subplot(2,2,2);
    plot(ROC_dense, alt_dense, 'm-', 'LineWidth', 2); hold on;
    yline(ac.ServiceCeiling_m, 'b--', 'LineWidth', 1.5, 'Label', sprintf('Service Ceiling = %dm', round(ac.ServiceCeiling_m)));
    yline(ac.AbsoluteCeiling_m, 'k:', 'LineWidth', 1.5, 'Label', sprintf('Absolute Ceiling = %dm', round(ac.AbsoluteCeiling_m)));
    grid on; box on; xlim([0, ac.ROC_max_sl * 1.15]);
    xlabel('Max Rate of Climb, ROC (m/s)', 'FontWeight', 'bold');
    ylabel('Altitude, h (m)', 'FontWeight', 'bold');
    title('Climb Rate vs Altitude');

    subplot(2,2,[3,4]);
    plot(V_env, n_pos_stall, 'k--', 'LineWidth', 1.5); hold on;
    plot(V_env, n_neg_stall, 'k--', 'LineWidth', 1.5);
    yline(ac.n_max, 'r-', 'LineWidth', 2);
    yline(ac.n_min, 'r-', 'LineWidth', 2);
    xline(V_A, 'b:', 'LineWidth', 1.5, 'Label', sprintf('V_A = %.1fm/s', V_A));
    xline(V_C, 'b--', 'LineWidth', 1.5, 'Label', sprintf('V_C = %.1fm/s', V_C));
    xline(V_D, 'b-', 'LineWidth', 2.0, 'Label', sprintf('V_D = %.1fm/s', V_D));

    plot(V_env(V_env <= V_C), n_gust_pos_cr(V_env <= V_C), 'g-.', 'LineWidth', 1.8);
    plot(V_env(V_env <= V_C), n_gust_neg_cr(V_env <= V_C), 'g-.', 'LineWidth', 1.8);

    grid on; box on; ylim([ac.n_min - 1.5, ac.n_max + 1.5]); xlim([0, V_D * 1.08]);
    xlabel('Equivalent Airspeed, EAS (m/s)', 'FontWeight', 'bold');
    ylabel('Load Factor, n (g)', 'FontWeight', 'bold');
    title(sprintf('%s - V-n Maneuver & Gust Structural Flight Envelope', ac.name), 'FontSize', 12, 'FontWeight', 'bold');
    legend({'Positive Stall Boundary', 'Negative Stall Boundary', 'Structural Limit (+6g / -3g)', ...
            '', '', '', '', 'FAR-23 Gust Boundary (50 ft/s)'}, 'Location', 'northwest', 'FontSize', 9);

    perf_res.ROC_dense = ROC_dense;
end

%% --- MODULE 4 FUNCTION ---
function [ac, stab_res] = run_module4_stability(ac, ~)
    g0 = 9.80665;
    [~, ~, ~, rho_cr] = atmos_isa_local(ac.alt_cr_m);
    V0 = ac.V_cruise_ms;
    m  = ac.W0_kg;
    S  = ac.S_wing_m2;
    b  = ac.b_span_m;
    c  = ac.MAC_m;
    q_dyn = 0.5 * rho_cr * (V0^2);

    Ix = 0.08 * m * (b^2);
    Iy = 0.12 * m * (4.2^2);
    Iz = 0.16 * m * (b^2);

    % Static Stability
    l_tail = 2.1;
    V_H = (0.22 * S * l_tail) / (S * c);
    deps_dalpha = (2 * ac.CL_alpha_rad) / (pi * ac.AR);
    CL_alpha_tail = 3.65;

    h_np = 0.25 + V_H * (CL_alpha_tail / ac.CL_alpha_rad) * (1 - deps_dalpha);
    ac.X_NP_m = h_np * c;
    ac.StaticMargin = 0.12;
    ac.X_CG_m = (h_np - ac.StaticMargin) * c;
    h_cg = ac.X_CG_m / c;
    ac.Cm_alpha_rad = - ac.CL_alpha_rad * (h_np - h_cg);

    fprintf('   -> Neutral Point Location (X_NP) : %5.3f m (%.1f%% MAC)\n', ac.X_NP_m, h_np*100);
    fprintf('   -> Center of Gravity (X_CG)      : %5.3f m (%.1f%% MAC)\n', ac.X_CG_m, h_cg*100);
    fprintf('   -> Static Margin (SM)            : %5.1f%% MAC (Statistically Stable)\n', ac.StaticMargin*100);
    fprintf('   -> Pitch Stiffness (Cm_alpha)    : %6.4f /rad (%6.4f /deg)\n', ac.Cm_alpha_rad, ac.Cm_alpha_rad*pi/180);

    % Stability Derivatives
    CL_u = 0.05;   CD_u = 0.0;     Cm_u = 0.0;
    CL_a = ac.CL_alpha_rad; CD_a = 2 * ac.K_ind * (ac.W0_N / (q_dyn*S)) * CL_a;
    CL_ad = 1.4;   CD_ad = 0.0;    Cm_ad = -2.8;
    CL_q = 3.8;    CD_q = 0.0;     Cm_q  = -7.5;
    CL_de = 0.42;  CD_de = 0.02;   Cm_de = -1.15;

    CY_beta = -0.38;   Cl_beta = -0.095;  Cn_beta = 0.125;
    CY_p    = -0.05;   Cl_p    = -0.420;  Cn_p    = -0.035;
    CY_r    =  0.18;   Cl_r    =  0.085;  Cn_r    = -0.160;

    % Dimensional Matrix Construction
    Xu = - (q_dyn * S / (m * V0)) * (2 * ac.CD0 + CL_u);
    Xw =   (q_dyn * S / (m * V0)) * (ac.CL_opt - CD_a);
    Zu = - (q_dyn * S / (m * V0)) * (2 * ac.CL_opt + CL_u);
    Zw = - (q_dyn * S / (m * V0)) * (CL_a + ac.CD0);
    Zq = - (q_dyn * S * c / (2 * m * V0)) * CL_q;
    Zwd= - (q_dyn * S * c / (2 * m * (V0^2))) * CL_ad;

    Mu = 0;
    Mw =   (q_dyn * S * c / (Iy * V0)) * ac.Cm_alpha_rad;
    Mq =   (q_dyn * S * (c^2) / (2 * Iy * V0)) * Cm_q;
    Mwd=   (q_dyn * S * (c^2) / (2 * Iy * (V0^2))) * Cm_ad;

    X_de = (q_dyn * S / m) * (-CD_de);
    Z_de = (q_dyn * S / m) * (-CL_de);
    M_de = (q_dyn * S * c / Iy) * Cm_de;

    M_factor = 1 / (1 - Zwd);
    A_lon = [
        Xu,               Xw,               0,                  -g0;
        M_factor*Zu,      M_factor*Zw,      M_factor*(V0 + Zq), 0;
        Mu + Mwd*M_factor*Zu, Mw + Mwd*M_factor*Zw, Mq + Mwd*M_factor*(V0 + Zq), 0;
        0,                0,                1,                  0
    ];
    B_lon = [X_de; M_factor * Z_de; M_de + Mwd * M_factor * Z_de; 0];

    Yv = (q_dyn * S / (m * V0)) * CY_beta;
    Yp = (q_dyn * S * b / (2 * m * V0)) * CY_p;
    Yr = (q_dyn * S * b / (2 * m * V0)) * CY_r;
    Lv = (q_dyn * S * b / (Ix * V0)) * Cl_beta;
    Lp = (q_dyn * S * (b^2) / (2 * Ix * V0)) * Cl_p;
    Lr = (q_dyn * S * (b^2) / (2 * Ix * V0)) * Cl_r;
    Nv = (q_dyn * S * b / (Iz * V0)) * Cn_beta;
    Np = (q_dyn * S * (b^2) / (2 * Iz * V0)) * Cn_p;
    Nr = (q_dyn * S * (b^2) / (2 * Iz * V0)) * Cn_r;

    A_lat = [
        Yv,      Yp,      Yr - V0,   g0;
        Lv,      Lp,      Lr,        0;
        Nv,      Np,      Nr,        0;
        0,       1,       0,         0
    ];

    % Modal Decomposition
    [Wn_lon, Z_lon, P_lon] = damp(A_lon);
    [Wn_lat, Z_lat, P_lat] = damp(A_lat);

    [~, idx_sort_lon] = sort(Wn_lon, 'descend');
    ac.wn_sp  = Wn_lon(idx_sort_lon(1));
    ac.zeta_sp= Z_lon(idx_sort_lon(1));
    ac.wn_ph  = Wn_lon(idx_sort_lon(3));
    ac.zeta_ph= Z_lon(idx_sort_lon(3));

    is_complex = abs(imag(P_lat)) > 1e-4;
    idx_dr = find(is_complex, 1);
    ac.wn_dr   = Wn_lat(idx_dr);
    ac.zeta_dr = Z_lat(idx_dr);
    real_poles = real(P_lat(~is_complex));
    ac.tau_roll = -1 / min(real_poles);

    fprintf('\n   === LONGITUDINAL DYNAMIC MODES ===\n');
    fprintf('   -> Short-Period Mode : wn = %5.3f rad/s, zeta = %5.3f (Level 1 Req: 0.35-1.30)\n', ...
            ac.wn_sp, ac.zeta_sp);
    fprintf('   -> Phugoid Mode      : wn = %5.3f rad/s, zeta = %5.3f (Level 1 Req: >0.04)\n', ...
            ac.wn_ph, ac.zeta_ph);
    fprintf('\n   === LATERAL-DIRECTIONAL DYNAMIC MODES ===\n');
    fprintf('   -> Dutch Roll Mode   : wn = %5.3f rad/s, zeta = %5.3f (MIL-F-8785C Level 1 Compliant)\n', ...
            ac.wn_dr, ac.zeta_dr);
    fprintf('   -> Roll Subsidence   : tau = %5.3f s (Fast Roll Response, Level 1: <1.4s)\n', ac.tau_roll);

    % Simulation
    t_sim = linspace(0, 30, 600);
    sys_lon = ss(A_lon, B_lon, eye(4), zeros(4,1));
    u_pulse = zeros(length(t_sim), 1);
    u_pulse(t_sim >= 1.0 & t_sim <= 2.0) = - deg2rad(2.0);
    [y_lon, t_out] = lsim(sys_lon, u_pulse, t_sim);

    % Plot Figure 4
    figure('Name', 'Figure 4 - 6-DOF Stability & Flight Dynamics', 'Color', 'w', 'Position', [250 250 1000 700]);
    subplot(2,2,1);
    plot(real(P_lon), imag(P_lon), 'bx', 'MarkerSize', 10, 'LineWidth', 2); hold on;
    plot(real(P_lat), imag(P_lat), 'ro', 'MarkerSize', 9, 'LineWidth', 2);
    xline(0, 'k:'); yline(0, 'k:'); grid on; box on;
    xlabel('Real Axis \sigma (1/s)', 'FontWeight', 'bold');
    ylabel('Imaginary Axis j\omega (rad/s)', 'FontWeight', 'bold');
    title('6-DOF Complex Pole Map (S-Plane)');
    legend({'Longitudinal Modes (SP & Phugoid)', 'Lateral Modes (Dutch Roll, Roll, Spiral)'}, ...
           'Location', 'best', 'FontSize', 9);

    subplot(2,2,2);
    alpha_deg_resp = rad2deg(y_lon(:,2) ./ V0);
    plot(t_out, alpha_deg_resp, 'b-', 'LineWidth', 2); grid on; box on;
    xlabel('Time, t (s)', 'FontWeight', 'bold');
    ylabel('\Delta\alpha (deg)', 'FontWeight', 'bold');
    title('Angle of Attack (\Delta\alpha) Response to Elevator Pulse');

    subplot(2,2,3);
    q_deg_resp = rad2deg(y_lon(:,3));
    plot(t_out, q_deg_resp, 'm-', 'LineWidth', 2); grid on; box on;
    xlabel('Time, t (s)', 'FontWeight', 'bold');
    ylabel('Pitch Rate, q (deg/s)', 'FontWeight', 'bold');
    title('Pitch Rate (q) Dynamic Response');

    subplot(2,2,4);
    theta_deg_resp = rad2deg(y_lon(:,4));
    plot(t_out, theta_deg_resp, 'k-', 'LineWidth', 2); grid on; box on;
    xlabel('Time, t (s)', 'FontWeight', 'bold');
    ylabel('Pitch Attitude, \Delta\theta (deg)', 'FontWeight', 'bold');
    title('Pitch Attitude (\Delta\theta) Phugoid Oscillation');

    stab_res.A_lon = A_lon;
end

%% --- MODULE 5 FUNCTION ---
function run_module5_export(ac)
    script_filename = 'uav_stealth_geometry.vspscript';
    fid = fopen(script_filename, 'w');
    if fid ~= -1
        fprintf(fid, '// OpenVSP AngelScript: %s\n', ac.name);
        fprintf(fid, 'void main()\n{\n');
        fprintf(fid, '    ClearVSPModel();\n\n');
        fprintf(fid, '    string wing_id = AddGeom("WING", "MainWing");\n');
        fprintf(fid, '    SetParmVal(wing_id, "TotalArea", "WingGeom", %f);\n', ac.S_wing_m2);
        fprintf(fid, '    SetParmVal(wing_id, "TotalSpan", "WingGeom", %f);\n', ac.b_span_m);
        fprintf(fid, '    SetParmVal(wing_id, "Sweep", "XSec_1", %f);\n', ac.sweep_deg);
        fprintf(fid, '    SetParmVal(wing_id, "Taper", "XSec_1", %f);\n', ac.taper_ratio);
        fprintf(fid, '    SetParmVal(wing_id, "ThickChord", "XSecCurve_0", %f);\n', ac.t_c);
        fprintf(fid, '    SetParmVal(wing_id, "ThickChord", "XSecCurve_1", %f);\n', ac.t_c);
        fprintf(fid, '    SetParmVal(wing_id, "X_Rel_Location", "XForm", %f);\n\n', ac.c_root_m * 0.4);

        fprintf(fid, '    string fuse_id = AddGeom("FUSELAGE", "StealthFuselage");\n');
        fprintf(fid, '    SetParmVal(fuse_id, "Length", "Design", 4.20);\n');
        fprintf(fid, '    SetParmVal(fuse_id, "Width", "Design", 0.72);\n');
        fprintf(fid, '    SetParmVal(fuse_id, "Height", "Design", 0.58);\n\n');

        fprintf(fid, '    string vtail_id = AddGeom("WING", "CantedVTail");\n');
        fprintf(fid, '    SetParmVal(vtail_id, "TotalArea", "WingGeom", %f);\n', 0.22 * ac.S_wing_m2);
        fprintf(fid, '    SetParmVal(vtail_id, "TotalSpan", "WingGeom", %f);\n', 0.45 * ac.b_span_m);
        fprintf(fid, '    SetParmVal(vtail_id, "Sweep", "XSec_1", 38.0);\n');
        fprintf(fid, '    SetParmVal(vtail_id, "Dihedral", "XSec_1", 38.0);\n');
        fprintf(fid, '    SetParmVal(vtail_id, "X_Rel_Location", "XForm", 3.40);\n\n');

        fprintf(fid, '    Update();\n');
        fprintf(fid, '    Print("Paninian UAV OpenVSP Model Generated Successfully!\\n");\n');
        fprintf(fid, '}\n');
        fclose(fid);
    end

    datcom_filename = 'uav_datcom_aero_summary.txt';
    fid_dat = fopen(datcom_filename, 'w');
    if fid_dat ~= -1
        fprintf(fid_dat, '========================================================================\n');
        fprintf(fid_dat, '  USAF DATCOM GEOMETRY & DERIVATIVE SUMMARY DECK - %s\n', ac.name);
        fprintf(fid_dat, '========================================================================\n\n');
        fprintf(fid_dat, '$FLTCON MACH=%4.2f, ALT=%5.1f, WT=%6.1f $\n', ac.V_cruise_ms / 340.0, ac.alt_cr_m, ac.W0_kg * 9.80665);
        fprintf(fid_dat, '$OPTINS SREF=%5.2f, CBARR=%5.2f, BLREF=%5.2f $\n', ac.S_wing_m2, ac.MAC_m, ac.b_span_m);
        fprintf(fid_dat, '$SYNTHS XCG=%5.2f, XNP=%5.2f, SM=%4.1f%% $\n', ac.X_CG_m, ac.X_NP_m, ac.StaticMargin * 100);
        fprintf(fid_dat, 'CL_alpha = %6.4f /rad, CD0 = %6.4f, K = %6.4f, (L/D)max = %5.2f\n', ...
                ac.CL_alpha_rad, ac.CD0, ac.K_ind, ac.LD_max);
        fclose(fid_dat);
    end

    fprintf('   -> Generated OpenVSP Script : %s\n', script_filename);
    fprintf('   -> Generated DATCOM Deck    : %s\n', datcom_filename);
end

%% --- HELPER: STANDARD ISA ATMOSPHERE ---
function [T, P, a   , rho] = atmos_isa_local(h)
    T0 = 288.15; P0 = 101325; gamma = 1.4; R_air = 287.05; L = 0.0065; g = 9.80665;
    if h <= 11000
        T = T0 - L * h;
        P = P0 * (T / T0)^(g / (R_air * L));
    else
        T11 = T0 - L * 11000;
        P11 = P0 * (T11 / T0)^(g / (R_air * L));
        T = T11;
        P = P11 * exp(-g * (h - 11000) / (R_air * T));
    end
    rho = P / (R_air * T);
    a = sqrt(gamma * R_air * T);
end